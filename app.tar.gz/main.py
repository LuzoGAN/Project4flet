import flet
from flet import *

def main(page: Page):
    #Titulo
    page.title = "Portifolio"

    def on_resize(e):
        if page.width <= 730:
            _nav.controls[0].visible = False
            _nav.update()
        else:
            _nav.controls[0].visible = True
            _nav.update()

    def _change_text_color(e):
        if e.control.content.color == "black":
            e.control.content.color = 'blue800',
            e.control.content.update()
        else:
            e.control.content.color = 'black',
            e.control.content.update()

    #Navegador
    _nav= Row(
        alignment="end",
        controls=[
            Container(
                padding=padding.only(right=20),
                bgcolor='pink',
                height=64,
                #width=64,
                content=Row(
                    controls=[
                        Container(on_hover=lambda e:_change_text_color(e),content=Text('Sobre',color='black')),
                        Container(on_hover=lambda e:_change_text_color(e),content=Text('Contato',color='black')),
                        Container(on_hover=lambda e:_change_text_color(e),content=Text('Serviços',color='black'))
                    ]
                )
            )
        ]
    )

    # Tirulos
    _title = ResponsiveRow(
        vertical_alignment="center",
        controls=[
            Text("Teste")
        ]
    )

    #main
    _main_col = Column()
    _main_col.controls.append(_nav)

    # Background do container
    _background = Container(
        height=page.height,
        margin=-10,
        gradient=LinearGradient(
            begin=alignment.bottom_left,
            end=alignment.top_right,
            colors=['#13547a','#80d0c7'],

        ),
        content=_main_col,
    )
    page.add(_background)

    # Redimensionamento
    page.on_resize = on_resize

#if __name__ == "__main__":
#    flet.app(target=main)
app(target=main)
